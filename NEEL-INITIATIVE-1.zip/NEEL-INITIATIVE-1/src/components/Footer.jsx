import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>© 2024 Neel-Initiatives. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;
